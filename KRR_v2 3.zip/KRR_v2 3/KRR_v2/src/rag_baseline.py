

import json
import numpy as np
import torch
import faiss

from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModelForCausalLM



# 1) Paths

data_path = "../data/cyber_facts.json"

generator_name = "gpt2-medium"
embedder_name  = "sentence-transformers/all-MiniLM-L6-v2"

device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")



# 2) Load dataset


with open(data_path, "r", encoding="utf-8") as f:
    raw_data = json.load(f)

print(f"Loaded {len(raw_data)} QA pairs")

documents = []
for item in raw_data:
    doc_text = f"Question: {item['question']}\nAnswer: {item['answer']}"
    documents.append(doc_text)



# 3) Build embeddings + FAISS index


print("Loading embedding model...")
embedder = SentenceTransformer(embedder_name)

print("Encoding documents...")
doc_embeddings = embedder.encode(
    documents,
    convert_to_numpy=True,
    normalize_embeddings=True
).astype("float32")

dimension = doc_embeddings.shape[1]
index = faiss.IndexFlatIP(dimension)
index.add(doc_embeddings)

print(f"FAISS index built with {index.ntotal} documents")



# 4) Load GPT-2


print("Loading GPT-2 Medium...")
tokenizer  = AutoTokenizer.from_pretrained(generator_name)
generator  = AutoModelForCausalLM.from_pretrained(generator_name).to(device)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

generator.config.pad_token_id = tokenizer.eos_token_id
generator.eval()
print("Model loaded successfully")



# 5) Retrieval


def retrieve_context(query: str, top_k: int = 3):
    query_emb = embedder.encode(
        [query],
        convert_to_numpy=True,
        normalize_embeddings=True
    ).astype("float32")

    scores, indices = index.search(query_emb, top_k)

    return [
        {"text": documents[idx], "score": float(score)}
        for idx, score in zip(indices[0], scores[0])
    ]


# 6) Answer generation


def answer_with_rag(question: str, top_k: int = 3) -> str:
    retrieved = retrieve_context(question, top_k=top_k)
    context   = "\n\n".join([doc["text"] for doc in retrieved])

    prompt = f"""You are a cybersecurity assistant.
Answer using ONLY the context below. If not found, say: I don't know.

Context:
{context}

Question: {question}
Answer:"""

    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=True,
        max_length=1024,
        truncation_side="left"
    )
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = generator.generate(
            **inputs,
            max_new_tokens=80,
            do_sample=False,
            repetition_penalty=1.1,
            eos_token_id=tokenizer.eos_token_id,
            pad_token_id=tokenizer.eos_token_id,
        )

    full_text = tokenizer.decode(outputs[0], skip_special_tokens=True)

    last_pos = full_text.rfind("Answer:")
    answer   = full_text[last_pos + len("Answer:"):].strip() if last_pos != -1 else full_text

    for stop in ["Context:", "Question:", "Note:", "Explanation:"]:
        if stop in answer:
            answer = answer.split(stop)[0].strip()

    return answer.split("\n")[0].strip()


# 7) Test


test_questions = [
    "What is phishing?",
   "How does social engineering work?",
   "Define malware",
    "What is ransomware?",
    "What is encryption?",
    "What is a VPN?",
   "Why use a VPN?",
    "What is a firewall?",
    "What is a DDoS attack?",
    "What is a trojan horse?",
    "Why is 2FA important?",
    "How do hackers steal passwords?",
    "What is identity theft?",
    "How can users protect their passwords?",
    "Explain phishing attacks",
]


print("\nTesting RAG:\n")
for q in test_questions:
    print(f"Q: {q}")
    print(f"A: {answer_with_rag(q)}")
    print("-" * 70)
