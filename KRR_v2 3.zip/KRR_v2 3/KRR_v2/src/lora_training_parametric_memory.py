# gpt2-medium 

import json
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
)
from peft import LoraConfig, get_peft_model, TaskType

# 1) Load data
with open("data/cyber_facts.json", "r", encoding="utf-8") as f:
    raw_data = json.load(f)

print(f"Loaded {len(raw_data)} unique QA pairs.\n")

# 2) Convert to text format
data = []
for item in raw_data:
    text = f"Question: {item['question']}\nAnswer: {item['answer']}"
    data.append({"text": text})

dataset = Dataset.from_list(data)

# 3) Load gpt2-medium (frozen)
model_name = "gpt2-medium"
print("Loading gpt2-medium ")

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)


tokenizer.pad_token = tokenizer.eos_token 
model.config.pad_token_id = tokenizer.eos_token_id 
import torch
device = "cuda" if torch.cuda.is_available() else "cpu"
model.to(device)

print("gpt2-medium loaded successfully!\n")

# 4) Apply LoRA
lora_config = LoraConfig(
    task_type=TaskType.CAUSAL_LM,
    r=8,
    lora_alpha=32,
    lora_dropout=0.05,
    target_modules=["c_attn", "c_proj"],  # gpt2-medium layers
    bias="none",
)

model = get_peft_model(model, lora_config)
model.to(device)
model.print_trainable_parameters()
print()

# 5) Tokenize dataset
def preprocess(example):
    tokenized = tokenizer(
        example["text"],
        truncation=True,
        padding="max_length",
        max_length=128,
    )
    tokenized["labels"] = tokenized["input_ids"].copy()
    return tokenized

tokenized_dataset = dataset.map(preprocess, remove_columns=["text"])

# 6) Training configuration
training_args = TrainingArguments(
    output_dir="results/lora_model_medium",
    per_device_train_batch_size=4,
    num_train_epochs=100,
    learning_rate=3e-4,
    logging_steps=20,
    save_strategy="no",
    report_to="none",
    fp16=False,
)

data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

# 7) Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_dataset,
    data_collator=data_collator,
)

# 8) Train
print("Starting LoRA training \n")
trainer.train()
print("\nLoRA training finished!\n")

# 9) Test
def generate_answer(question: str) -> str:
    prompt = f"Question: {question}\nAnswer:"
    
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    newline_token = tokenizer.encode("\n", add_special_tokens=False)

    outputs = model.generate(
        **inputs,
        max_new_tokens=60,
        do_sample=False,
        num_beams=3,
        repetition_penalty=2.5,
        no_repeat_ngram_size=4,
        eos_token_id=newline_token[0] if newline_token else tokenizer.eos_token_id,
        pad_token_id=tokenizer.eos_token_id,
    )

    full_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
    answer = full_text.split("Answer:")[-1].strip()
    for stop in [".", "\n", "Question:"]:
        if stop in answer:
            answer = answer.split(stop)[0].strip() + ("." if stop == "." else "")
            break
    return answer


print("=" * 50)
print("Testing Parametric Memory (LoRA - gpt2-medium):\n")

test_questions = [
    "What is phishing?",
   "How does social engineering work?",
   "Define malware",
    "What is ransomware?",
    "What is encryption?",
    "What is a VPN?",
   "Why use a VPN?",
    "What is a firewall?",
    "What is a DDoS attack?",
    "What is a trojan horse?",
    "Why is 2FA important?",
    "How do hackers steal passwords?",
    "What is identity theft?",
    "How can users protect their passwords?",
    "Explain phishing attacks",
]

for q in test_questions:
    print(f"Q: {q}")
    print(f"A: {generate_answer(q)}")
    print("-" * 40)

# 10) Save
save_path = "results/lora_model_medium/final_adapter"
model.save_pretrained(save_path)
tokenizer.save_pretrained(save_path)

print(f"\nLoRA adapter saved to: {save_path}")
print("Note: Only adapter weights are saved — base model stays unchanged.")
